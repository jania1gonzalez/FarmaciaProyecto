/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fecucei;

import DBPackage.ConnectionDB;
import DBPackage.UsuariosT;
import DBPackage.ClientesT;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JOptionPane;

public class FECUCEI {

    public static void main(String[] args) {
        ClientesT clientsHandler = new ClientesT();
        mainWindow login = new mainWindow();
        login.setVisible(true);
    }

}
