/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBPackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author under
 */
public class ConnectionDB {
    //jdbc:mysql://URL o HOST:PORT/DATABASE NAME

    private String URL = "jdbc:mysql://fecucei-do-user-15679536-0.e.db.ondigitalocean.com:25060/defaultdb";
    private String user = "doadmin";
    private String pass = "AVNS_mCF3iFL5KX_4W8t8Y-L";
    private String SSL = "?useSSL=true";
    private Connection cnx;

    public Connection getCnx() {
        return cnx;
    }

    public void setCnx(Connection cnx) {
        this.cnx = cnx;
    }

    public boolean establishConnection() {
        Connection Auxcnx = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Auxcnx = DriverManager.getConnection(URL + SSL, user, pass);
            setCnx(Auxcnx);
            return true;

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar el driver JDBC: " + e.getMessage());
            return false;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e.getMessage());
            return false;
        }
    }

    public void finishConnection() {
        try {
            this.cnx.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al desconectar a la base de datos: " + ex.getMessage());
            Logger.getLogger(ConnectionDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void resetConnection() {
        try {
            if (!this.cnx.isClosed()) {
                this.finishConnection();
                this.establishConnection();
            }

        } catch (SQLException ex) {
        }
    }
}
