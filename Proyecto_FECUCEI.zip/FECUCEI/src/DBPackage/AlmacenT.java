/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBPackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author under
 */
public class AlmacenT {

    ConnectionDB cnxHandler;
    Connection cnx;
    Statement stm;
    ResultSet rs;
    PreparedStatement pstm;

    public AlmacenT() {
        this.cnxHandler = new ConnectionDB();
        if (cnxHandler.establishConnection()) {
            this.cnx = cnxHandler.getCnx();
            //System.out.println("Conexión establecida\nObjeto de tipo Almacen");
        } else {
            JOptionPane.showMessageDialog(null, "Error al establecer conexión\nObjeto de tipo Compra");
        }
    }

    public void createStatement() {

        try {
            this.stm = this.cnx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear Statement\nObjeto de tipo almacen\n" + ex);
        }

    }

    public void closeStatement() {
        try {
            this.stm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar Statement\nObjeto de tipo almacen\n" + ex);
        }
    }

    public void closeRS() {
        try {
            this.rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el resultSet\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public void createPreparedStatement(String query) {
        try {
            this.pstm = this.cnx.prepareStatement(query);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public void closePreparedStatement() {
        try {
            this.pstm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public ArrayList<String> getPNameByName(String name) {
        String query = "SELECT nombrePAlmacen FROM almacen WHERE nombrePAlmacen = ?;";
        ArrayList<String> results = new ArrayList<>();
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, name);
            this.rs = this.pstm.executeQuery();
            if (!this.rs.next()) {
                return null;
            }

            do {

                results.add(this.rs.getString("nombrePAlmacen"));

            } while (this.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al obtener el nombre del producto->AlmacenT()\n" + ex);
            return null;
        }

        return results;

    }

    public String getLastID() {
        String query = "SELECT MAX(idAlmacen) FROM almacen;";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            if (this.rs.next()) {
                result = String.valueOf(this.rs.getInt("MAX(idAlmacen)"));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el último ID\nAlmacen->getLastID()\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public ArrayList<String[]> getRowByID(int ID) {

        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM defaultdb.almacen WHERE idAlmacen = ?";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, ID);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ejecutar la consulta\nObjeto de tipo Usuarios\n" + ex.getMessage());
            return null;
        }

        try {
            if (!this.rs.next()) {
                return null;
            }
            do {
                try {
                    String idAlmacen = String.valueOf(this.rs.getInt("idAlmacen"));
                    String nombrePAlmacen = this.rs.getString("nombrePAlmacen");
                    String cantidadAlmacen = String.valueOf(this.rs.getInt("cantidadPAlmacen"));
                    String precioAlmacen = String.valueOf(this.rs.getFloat("precioPAlmacen"));

                    String[] resultsArr = {idAlmacen, nombrePAlmacen, cantidadAlmacen, precioAlmacen};
                    results.add(resultsArr);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro\nObjeto de tipo Almacen\n" + ex);
                    return null;
                }
            } while (this.rs.next());

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener un registro 'rs.next()'\nObjeto de tipo Almacen\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String[]> getTable() {
        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM almacen;";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar la consulta\nAlmacen->getTableID\n" + ex);
            return null;
        }

        try {
            while (this.rs.next()) {
                try {
                    String idAlmacen = String.valueOf(this.rs.getInt("idAlmacen"));
                    String nombrePAlmacen = this.rs.getString("nombrePAlmacen");
                    String cantidadAlmacen = String.valueOf(this.rs.getInt("cantidadAlmacen"));
                    String precioAlmacen = String.valueOf(this.rs.getFloat("precioAlmacen"));
                    String[] resultsArr = {idAlmacen, nombrePAlmacen, cantidadAlmacen, precioAlmacen};
                    results.add(resultsArr);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro\nAlmacen->getTable()->while(this.rs.next())\n" + ex);
                    return null;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener una o más filas\nAlmacen->getTable()\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public String getPAmountByID(String ID) {
        String query = "SELECT cantidadPAlmacen FROM almacen WHERE idAlmacen = ?";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(ID));
            this.rs = this.pstm.executeQuery();
            if (!this.rs.next()) {
                return null;
            }
            do {
                result = this.rs.getString("cantidadPAlmacen");
            } while (this.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "No se pudo obtener el registro\nAlmacenT()->getPAmountByID()\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }
    

    public String getPIDByName(String name) {
        String query = "SELECT idAlmacen FROM almacen WHERE nombrePAlmacen= ?";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, name);
            this.rs = this.pstm.executeQuery();
            if (!this.rs.next()) {
                return null;
            }
            do {
                result = this.rs.getString("idAlmacen");
            } while (this.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "No se pudo obtener el registro\nAlmacenT()->getPAmountByID()\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public boolean updatePAmountByID(String ID, String amount) {
        String query = "UPDATE almacen SET cantidadPAlmacen = ? WHERE idAlmacen = ?";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(amount));
            this.pstm.setInt(2, Integer.parseInt(ID));
            this.pstm.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al actualizar la cantidad del producto solicitado\nAlmacenT()->updatePAmountByID()->ID:" + ID + "\n" + ex);
            return false;
        }
        this.closePreparedStatement();
        return true;
    }

    public String getPNameByID(String ID) {
        String query = "SELECT nombrePAlmacen FROM almacen WHERE idAlmacen = ?";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, ID);
            this.rs = this.pstm.executeQuery();
            if (this.rs.next()) {
                result = this.rs.getString("nombrePAlmacen");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el nombre\nAlmacenT()->getPNameByID()\n" + ex);
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;

    }

    public ArrayList<String> getColumnID() {
        String query = "SELECT idAlmacen FROM almacen;";
        ArrayList<String> results = new ArrayList<>();
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            while (this.rs.next()) {
                String idAlmacen = String.valueOf(this.rs.getInt("idAlmacen"));
                results.add(idAlmacen);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar la consulta->CompraT()->getColumnID()" + ex);
            return null;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar una conversion de dato->CompraT()->getColumnID()" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return results;

    }

    public ArrayList<String> getColumnName() {
        String query = "SELECT nombrePAlmacen FROM almacen;";
        ArrayList<String> results = new ArrayList<>();
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            while (this.rs.next()) {
                String nombreProducto = this.rs.getString("nombrePAlmacen");
                results.add(nombreProducto);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar la consulta\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String[]> getRowByName(String nombrePAlmacen) {
        String query = "SELECT * FROM almacen WHERE nombrePAlmacen = ?;";
        ArrayList<String[]> results = new ArrayList<String[]>();
        //String[] result = new String[4];
        this.createPreparedStatement(query);
        try {
            this.pstm.setString(1, nombrePAlmacen);
            this.rs = this.pstm.executeQuery();
            if (!this.rs.next()) {
                JOptionPane.showMessageDialog(null, "No se encontraron registros con este nombre.");
                return null;
            }
            do {
                String[] result = {this.rs.getString("idAlmacen"), this.rs.getString("nombrePAlmacen"), this.rs.getString("cantidadPAlmacen"), this.rs.getString("precioPAlmacen")};
                results.add(result);
            } while (this.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al realizar la consulta\n" + ex);
            return null;
        }
        return results;
    }

    public boolean insertRow(String nombrePAlmacen, String cantidadPAlmacen, String precioPAlmacen) {
        String query = "INSERT INTO almacen(nombrePAlmacen, cantidadPAlmacen, precioPAlmacen) VALUES(?,?,?);";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, nombrePAlmacen);
            this.pstm.setString(2, cantidadPAlmacen);
            this.pstm.setFloat(3, Float.parseFloat(precioPAlmacen));
            this.pstm.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al configurar query\n" + ex);
            return false;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Error al formatear el número\n" + ex);
            return false;
        }

        return true;

    }

    public boolean updateRow(String idAlmacen, String nombrePAlmacen, String cantidadPAlmacen, String precioPAlmacen) {
        String query = "UPDATE almacen SET nombrePAlmacen ?, cantidadPAlmacen = ?, precioPAlmacen = ? WHERE idAlmacen = ?;";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, nombrePAlmacen);
            this.pstm.setInt(2, Integer.parseInt(cantidadPAlmacen));
            this.pstm.setFloat(3, Float.parseFloat(precioPAlmacen));
            this.pstm.setInt(4, Integer.parseInt(idAlmacen));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ejecutar el query\n" + ex);
            return false;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Error al formatear el número." + ex);
            return false;
        }

        return true;

    }
}
