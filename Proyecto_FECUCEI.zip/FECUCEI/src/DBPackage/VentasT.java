/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBPackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author under
 */
public class VentasT {

    ConnectionDB cnxHandler;
    Connection cnx;
    Statement stm;
    ResultSet rs;
    PreparedStatement pstm;
    CarritoT carShopHandler;

    public VentasT() {
        this.cnxHandler = new ConnectionDB();
        this.carShopHandler = new CarritoT();
        if (cnxHandler.establishConnection()) {
            this.cnx = cnxHandler.getCnx();
            //System.out.println("Conexión establecida\nObjeto de tipo Almacen");
        } else {
            JOptionPane.showMessageDialog(null, "Error al establecer conexión\nObjeto de tipo Compra");
        }
    }

    public void createStatement() {

        try {
            this.stm = this.cnx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear Statement\nObjeto de tipo almacen\n" + ex);
        }

    }

    public void closeStatement() {
        try {
            this.stm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar Statement\nObjeto de tipo almacen\n" + ex);
        }
    }

    public void closeRS() {
        try {
            this.rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el resultSet\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public void createPreparedStatement(String query) {
        try {
            this.pstm = this.cnx.prepareStatement(query);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public void closePreparedStatement() {
        try {
            this.pstm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public String getLastID() {
        String query = "SELECT MAX(idVentas) FROM ventas;";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            if (this.rs.next()) {
                result = this.rs.getString("MAX(idVentas)");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el último ID\nVentasT()->getLastID()");
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public String[] getRowByID(String ID) {
        String query = "SELECT * FROM ventas WHERE idVentas = ?;";
        String[] result = new String[4];
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(ID));
            this.rs = this.pstm.executeQuery();
            if (!this.rs.next()) {
                JOptionPane.showMessageDialog(null, "No se encontró ningún registro.");
                return null;
            }
            do {
                result[0] = this.rs.getString("idVentas");
                result[1] = this.rs.getString("idClienteVentas");
                result[2] = this.rs.getString("idCarritoVentas");
                result[3] = this.rs.getString("totalVentas");
            } while (this.rs.next());
            this.closePreparedStatement();
            this.closeRS();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "No se pudo obtener el registro mediante ID\nVentasT()->getRowByID()\n" + ex.getMessage());
            return null;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "El ID insertado no es númerico.");
            return null;
        }
        return result;

    }

    public boolean insertRow(String idVentas, String idClienteVentas, String idCarritoVentas, String totalVentas) {
        String query = "INSERT INTO ventas(idVentas,idClienteVentas,idCarritoVentas,totalVentas) VALUES(?,?,?,?);";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(idVentas));
            this.pstm.setInt(2, Integer.parseInt(idClienteVentas));
            this.pstm.setInt(3, Integer.parseInt(idCarritoVentas));
            this.pstm.setFloat(4, Float.parseFloat(totalVentas));
            this.pstm.executeUpdate();
            this.closePreparedStatement();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al insertar el registro\n" + ex.getMessage());
            return false;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al formatear un número.\n" + ex.getMessage());
            return false;
        }
        return true;
    }

    public boolean updateTotalByID(String ID,String total) {
        String query = "UPDATE ventas SET totalVentas = ? WHERE idVentas = ?;";
        try{
            this.createPreparedStatement(query);
            this.pstm.setFloat(1, Float.parseFloat(total));
            this.pstm.setInt(2, Integer.parseInt(ID));
            this.pstm.executeUpdate();
            this.closePreparedStatement();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "No se pudo actualizar el total\n"+ex.getMessage());
            return false;
        }   
        return true;
    }

}
