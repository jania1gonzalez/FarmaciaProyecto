/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBPackage;

import java.awt.HeadlessException;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.PreparedStatement;

/**
 *
 * @author under
 */
public class UsuariosT {

    ConnectionDB cnxHandler;
    Connection cnx;
    Statement stm;
    ResultSet rs;
    PreparedStatement pstm;

    public UsuariosT() {
        this.cnxHandler = new ConnectionDB();
        if (cnxHandler.establishConnection()) {
            this.cnx = cnxHandler.getCnx();
            //System.out.println("Conexión establecida\nObjeto de tipo Usuarios");
        } else {
            JOptionPane.showMessageDialog(null, "Error al establecer conexión\nObjeto de tipo Usuarios");
        }
    }

    public void createStatement() {

        try {
            this.stm = this.cnx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear Statement\nObjeto de tipo usuarios\n" + ex);
        }

    }

    public void closeStatement() {
        try {
            this.stm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar Statement\nObjeto de tipo usuarios\n" + ex);
        }
    }

    public void closeRS() {
        try {
            this.rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el resultSet\nObjeto de tipo Usuarios\n" + ex.getMessage());
        }
    }

    public void createPreparedStatement(String query) {
        try {
            this.pstm = this.cnx.prepareStatement(query);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo Usuarios\n" + ex.getMessage());
        }
    }

    public void closePreparedStatement() {
        try {
            this.pstm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo Usuarios\n" + ex.getMessage());
        }
    }

    public String getLastID() {
        String query = "SELECT MAX(idUsuarios) FROM usuarios;";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            if (this.rs.next()) {
                result = this.rs.getString("MAX(idUsuarios)");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el último ID\nUsuarios->getLastID()\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public String getNameByID(String ID) {
        String result = "";
        String query = "SELECT nombreUsuarios FROM usuarios WHERE idUsuarios = ?";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(ID));
            this.rs = this.pstm.executeQuery();
            try {
                while (this.rs.next()) {
                    result = this.rs.getString("nombreUsuarios");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Hubo un error al obtener una fila\nUsuarios->getNameByID()\n" + ex);
                return null;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al obtener el nombre mediante el ID\nUsuarios->getNameByID\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public ArrayList<String[]> getRowByID(int ID) {

        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM defaultdb.usuarios WHERE idUsuarios = ?";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, ID);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ejecutar la consulta\nObjeto de tipo Usuarios\n" + ex.getMessage());
            return null;
        }

        try {
            if (!this.rs.next()) {
                return null;
            }

            do {
                try {
                    String idUsuarios = String.valueOf(this.rs.getInt("idUsuarios"));
                    String nombreUsuarios = this.rs.getString("nombreUsuarios");
                    String usernameUsuarios = this.rs.getString("usernameUsuarios");
                    String passwordUsuarios = this.rs.getString("passwordUsuarios");
                    String rolUsuarios = this.rs.getString("rolUsuarios");

                    String[] resultsArr = {idUsuarios, nombreUsuarios, usernameUsuarios, passwordUsuarios, rolUsuarios};
                    results.add(resultsArr);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro 'rs.getString()' or 'rs.getInt()'\nObjeto de tipo usuarios\n" + ex);
                    return null;
                }

            } while(this.rs.next()); 
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener un registro 'rs.next()'\nObjeto de tipo usuarios\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String[]> getRowByCredentials(String username, String passwords) {
        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM usuarios WHERE usernameUsuarios = ? AND passwordUsuarios = ?;";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, username);
            this.pstm.setString(2, passwords);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener registro con credenciales\nUsuarios->getRowByCredentials()\n" + ex);
            return null;
        }

        try {
            while (this.rs.next()) {
                String idUsuarios = String.valueOf(this.rs.getInt("idUsuarios"));
                String nombreUsuarios = this.rs.getString("nombreUsuarios");
                String usernameUsuarios = this.rs.getString("usernameUsuarios");
                String passwordUsuarios = this.rs.getString("passwordUsuarios");
                String rolUsuarios = this.rs.getString("rolUsuarios");
                String[] resultsArr = {idUsuarios, nombreUsuarios, usernameUsuarios, passwordUsuarios, rolUsuarios};
                results.add(resultsArr);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener un registro\nUsuarios->getTable()->while(this.rs.next())\n" + ex);
            return null;
        }

        if (results.size() > 1) {
            JOptionPane.showMessageDialog(null, "Existe más de un usuario con estás credenciales, por favor hable con el administrador.");
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String[]> getTable() {
        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM usuarios;";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar la consulta\nUsuarios->getTableID\n" + ex);
            return null;
        }

        try {
            while (this.rs.next()) {
                try {
                    String idUsuarios = String.valueOf(this.rs.getInt("idUsuarios"));
                    String nombreUsuarios = this.rs.getString("nombreUsuarios");
                    String usernameUsuarios = this.rs.getString("usernameUsuarios");
                    String passwordUsuarios = this.rs.getString("passwordUsuarios");
                    String rolUsuarios = this.rs.getString("rolUsuarios");
                    String[] resultsArr = {idUsuarios, nombreUsuarios, usernameUsuarios, passwordUsuarios, rolUsuarios};
                    results.add(resultsArr);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro\nUsuarios->getTable()->while(this.rs.next())\n" + ex);
                    return null;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener una o más filas\nUsuarios->getTable()\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String> getColumnID() {
        ArrayList<String> results = new ArrayList<>();
        String query = "SELECT idUsuarios FROM usuarios;";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar la consulta\nUsuarios->getColumnID\n" + ex);
            return null;
        }
        try {
            while (this.rs.next()) {
                results.add(String.valueOf(this.rs.getInt("idUsuarios")));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener una fila\nUsuarios->while(this.rs.next())\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public boolean insertRow(String nombreUsuarios, String usernameUsuarios, String passwordUsuarios, String rolUsuarios) {

        String query = "INSERT INTO usuarios(nombreUsuarios,usernameUsuarios,passwordUsuarios,rolUsuarios) VALUES(?,?,?,?);";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, nombreUsuarios);
            this.pstm.setString(2, usernameUsuarios);
            this.pstm.setString(3, passwordUsuarios);
            this.pstm.setString(4, rolUsuarios);
            this.pstm.executeUpdate();
            this.closePreparedStatement();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al agregar un registro\nObjeto de tipo usuarios\n" + ex);
            System.out.println(ex.getMessage());
            return false;
        }

    }

    public boolean updateRow(String idUsuarios, String nombreUsuarios, String usernameUsuarios, String passwordUsuarios, String rolUsuarios) {
        String query = "UPDATE usuarios SET nombreUsuarios= ?,usernameUsuarios= ?,passwordUsuarios= ?,rolUsuarios= ? WHERE idUsuarios = ?;";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, nombreUsuarios);
            this.pstm.setString(2, usernameUsuarios);
            this.pstm.setString(3, passwordUsuarios);
            this.pstm.setString(4, rolUsuarios);
            try {
                this.pstm.setInt(5, Integer.parseInt(idUsuarios));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Error al actualizar un registro\nEl número de id no es un número'\nUsuarios->UpdateRow()\n" + ex);
                return false;
            }
            this.pstm.executeUpdate();
            this.closePreparedStatement();
            return true;
        } catch (HeadlessException | SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al actualizar un registro\nObjeto de tipo usuarios\n" + ex);
            return false;
        }

    }

}
