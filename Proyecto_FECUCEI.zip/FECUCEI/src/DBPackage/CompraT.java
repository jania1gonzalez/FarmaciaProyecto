/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBPackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.lang.NumberFormatException;

/**
 *
 * @author under
 */
public class CompraT {

    ConnectionDB cnxHandler;
    Connection cnx;
    Statement stm;
    ResultSet rs;
    PreparedStatement pstm;
    AlmacenT storeHandler;

    public CompraT() {
        this.cnxHandler = new ConnectionDB();
        this.storeHandler = new AlmacenT();
        if (cnxHandler.establishConnection()) {
            this.cnx = cnxHandler.getCnx();
            //System.out.println("Conexión establecida\nObjeto de tipo Compra");
        } else {
            JOptionPane.showMessageDialog(null, "Error al establecer conexión\nObjeto de tipo Compra");
        }
    }

    public void createStatement() {

        try {
            this.stm = this.cnx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear Statement\nObjeto de tipo usuarios\n" + ex);
        }

    }

    public void closeStatement() {
        try {
            this.stm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar Statement\nObjeto de tipo usuarios\n" + ex);
        }
    }

    public void closeRS() {
        try {
            this.rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el resultSet\nObjeto de tipo Compra\n" + ex.getMessage());
        }
    }

    public void createPreparedStatement(String query) {
        try {
            this.pstm = this.cnx.prepareStatement(query);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo Compra\n" + ex.getMessage());
        }
    }

    public void closePreparedStatement() {
        try {
            this.pstm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo Compra\n" + ex.getMessage());
        }
    }
    
    
    
    public String getLastID() {
        String query = "SELECT MAX(idCompra) FROM compra;";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            if (this.rs.next()) {
                result = String.valueOf(this.rs.getInt("MAX(idCompra)"));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el último ID\nCompra->getLastID()\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public ArrayList<String[]> getRowByID(int ID) {

        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM defaultdb.compra WHERE idCompra = ?";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, ID);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ejecutar la consulta\nObjeto de tipo Usuarios\n" + ex.getMessage());
            return null;
        }

        try {
            if (!this.rs.next()) {
                return null;
            }
            do {
                try {
                    String idCompra = String.valueOf(this.rs.getInt("idCompra"));
                    String idProductoCompra = String.valueOf(this.rs.getInt("idProductoCompra"));
                    String stockCompra = String.valueOf(this.rs.getInt("stockCompra"));
                    String precioUCompra = String.valueOf(this.rs.getFloat("precioUCompra"));
                    String totalCompra = String.valueOf(this.rs.getFloat("totalCompra"));

                    String[] resultsArr = {idCompra, idProductoCompra, stockCompra, precioUCompra, totalCompra};
                    results.add(resultsArr);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro\nObjeto de tipo Compra\n" + ex);
                    return null;
                }
            } while (this.rs.next());

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener un registro 'rs.next()'\nObjeto de tipo Compra\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String[]> getTable() {
        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM compra;";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar la consulta\nCompra->getTableID\n" + ex);
            return null;
        }

        try {
            while (this.rs.next()) {
                try {
                    String idCompra = String.valueOf(this.rs.getInt("idCompra"));
                    String idProductoCompra = String.valueOf(this.rs.getInt("idProductoCompra"));
                    String stockCompra = String.valueOf(this.rs.getInt("stockCompra"));
                    String precioUCompra = String.valueOf(this.rs.getFloat("precioUCompra"));
                    String totalCompra = String.valueOf(this.rs.getFloat("totalCompra"));
                    String[] resultsArr = {idCompra, idProductoCompra, stockCompra, precioUCompra, totalCompra};
                    results.add(resultsArr);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro\nCompra->getTable()->while(this.rs.next())\n" + ex);
                    return null;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener una o más filas\nCompra->getTable()\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String> getColumnID(){
        String query = "SELECT idCompra FROM compra;";
        ArrayList<String> results = new ArrayList<>();
        try{
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            while(this.rs.next()){
                String idCompra = String.valueOf(this.rs.getInt("idCompra"));
                results.add(idCompra);
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Error al realizar la consulta->CompraT()->getColumnID()"+ex);
        }
        catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null,"Error al realizar una conversion de dato->CompraT()->getColumnID()"+ex);
        }
        this.closePreparedStatement();
        this.closeRS();
        return results;
        
    }
    
    public ArrayList<String[]> getRowsByDate(String date){
        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM compra WHERE fechaCompra = ?;";
        try{
            this.createPreparedStatement(query);
            this.pstm.setString(1, date);
            this.rs = this.pstm.executeQuery();
            while(this.rs.next()){
                String idCompra = this.rs.getString("idCompra");
                String idProductoCompra = this.rs.getString("idProductoCompra");
                String stockCompra = this.rs.getString("stockCompra");
                String precioUCompra = this.rs.getString("precioUCompra");
                String totalCompra = this.rs.getString("totalCompra");
                String fechaCompra = this.rs.getString("fechaCompra");
                String[] arrRow = {idCompra,idProductoCompra,stockCompra,precioUCompra,totalCompra,fechaCompra};
                results.add(arrRow);
            }
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Error al obtener la consulta\nCompraT()->getRowByID()\n"+ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return results;
    }
    
    public boolean insertRow(String idProductoCompra, String stockCompra, String precioUCompra, String totalCompra,String fechaCompra) {
        String query = "INSERT INTO compra(idProductoCompra,stockCompra,precioUCompra,totalCompra,fechaCompra) VALUES(?,?,?,?,?);";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(idProductoCompra));
            this.pstm.setInt(2, Integer.parseInt(stockCompra));
            this.pstm.setFloat(3, Float.parseFloat(precioUCompra));
            this.pstm.setFloat(4, Float.parseFloat(totalCompra));
            this.pstm.setString(5, fechaCompra);
            this.pstm.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al configurar query\n" + ex);
            return false;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Error al convertir algun valor.\n" + ex);
            return false;
        }
        
        this.closePreparedStatement();
        
        int newAmount = Integer.parseInt(this.storeHandler.getPAmountByID(idProductoCompra))+Integer.parseInt(stockCompra);
        
        return this.storeHandler.updatePAmountByID(idProductoCompra, String.valueOf(newAmount));

    }
    
    public boolean updateRow(String idCompra,String idProductoCompra, String stockCompra, String precioUCompra, String totalCompra,String fechaCompra){
        String query = "UPDATE compra SET idProductoCompra = ?, stockCompra = ?, precioUCompra = ?, totalCompra = ?, fechaCompra = ? WHERE idCompra = ?;";
        try{
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(idProductoCompra));
            this.pstm.setInt(2,Integer.parseInt(stockCompra));
            this.pstm.setFloat(3, Float.parseFloat(precioUCompra));
            this.pstm.setFloat(4, Float.parseFloat(totalCompra));
            this.pstm.setString(5, fechaCompra);
            this.pstm.setInt(6, Integer.parseInt(idCompra));
            this.pstm.executeUpdate();
            
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "No se pudo actualizar un registro\n");
            return false;
        }catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Error al convertir algun valor.\n" + ex);
            return false;
        }
        return true;
    }
}
