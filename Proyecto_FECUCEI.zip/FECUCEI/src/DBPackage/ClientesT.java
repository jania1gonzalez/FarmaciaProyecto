/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBPackage;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author under
 */
public class ClientesT {

    ConnectionDB cnxHandler;
    Connection cnx;
    Statement stm;
    ResultSet rs;
    PreparedStatement pstm;

    public ClientesT() {
        this.cnxHandler = new ConnectionDB();
        if (cnxHandler.establishConnection()) {
            this.cnx = cnxHandler.getCnx();
            //System.out.println("Conexión establecida\nObjeto de tipo Clientes");
        } else {
            JOptionPane.showMessageDialog(null, "Error al establecer conexión\nObjeto de tipo Clientes");
        }
    }

    public void createStatement() {

        try {
            this.stm = this.cnx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear Statement\nObjeto de tipo Clientes\n" + ex);
        }

    }

    public void closeStatement() {
        try {
            this.stm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar Statement\nObjeto de tipo Clientes\n" + ex);
        }
    }

    public void closeRS() {
        try {
            this.rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el resultSet\nObjeto de tipo Clientes\n" + ex.getMessage());
        }
    }

    public void createPreparedStatement(String query) {
        try {
            this.pstm = this.cnx.prepareStatement(query);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo Clientes\n" + ex.getMessage());
        }
    }

    public void closePreparedStatement() {
        try {
            this.pstm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo Clientes\n" + ex.getMessage());
        }
    }

    public String getLastID() {
        String query = "SELECT MAX(idClientes) FROM defaultdb.clientes;";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            if (this.rs.next()){
                result = this.rs.getString("MAX(idClientes)");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el último ID\nClientes->getLastID()\n" + ex);
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public ArrayList<String[]> getRowByID(int ID) {

        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM defaultdb.clientes WHERE idClientes = ?";
        try {
            this.createPreparedStatement(query);
            this.pstm.setInt(1, ID);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ejecutar la consulta\nObjeto de tipo Clientes\n" + ex.getMessage());
            return null;
        }

        try {
            if(!this.rs.next()){
                return null;
            }
            do { //OBTENEMOS LA FILA
                try {
                    String idClientes = String.valueOf(this.rs.getInt("idClientes"));
                    String idUsuariosClientes = String.valueOf(this.rs.getInt("idUsuariosClientes"));
                    String nombreCliente = this.rs.getString("nombreClientes");
                    String telefonoCliente = this.rs.getString("telefonoClientes");
                    String puntosCliente = this.rs.getString("puntosClientes");

                    String[] resultsArr = {idClientes, idUsuariosClientes, nombreCliente, telefonoCliente, puntosCliente};
                    results.add(resultsArr);

                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro 'rs.getString()' or 'rs.getInt()'\nObjeto de tipo Clientes\n" + ex);
                    return null;
                }
            }while(this.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener un registro 'rs.next()'\nObjeto de tipo Clientes\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public ArrayList<String[]> getTable() {
        ArrayList<String[]> results = new ArrayList<>();
        String query = "SELECT * FROM clientes;";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al realizar la consulta\nClientes->getTableID\n" + ex);
            return null;
        }

        try {
            while (this.rs.next()) {
                try {
                    String idClientes = String.valueOf(this.rs.getInt("idClientes"));
                    String idUsuariosClientes = String.valueOf(this.rs.getInt("idUsuariosClientes"));
                    String nombreCliente = this.rs.getString("nombreClientes");
                    String telefonoCliente = this.rs.getString("telefonoClientes");
                    String puntosCliente = this.rs.getString("puntosClientes");
                    String[] resultsArr = {idClientes, idUsuariosClientes, nombreCliente, telefonoCliente, puntosCliente};
                    results.add(resultsArr);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al obtener un registro\nClientes->getTable()->while(this.rs.next())\n" + ex);
                    return null;
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener una o más filas\nClientes->getTable()\n" + ex);
            return null;
        }

        this.closePreparedStatement();
        this.closeRS();
        return results;
    }

    public boolean insertRow(String idUsuariosClientes, String nombreClientes, String telefonoClientes, String puntosClientes) {

        String query = "INSERT INTO clientes(idUsuariosClientes,nombreClientes,telefonoClientes,puntosClientes) VALUES(?,?,?,?);";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, idUsuariosClientes);
            this.pstm.setString(2, nombreClientes);
            this.pstm.setString(3, telefonoClientes);
            this.pstm.setString(4, puntosClientes);
            this.pstm.executeUpdate();
            this.closePreparedStatement();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al agregar un registro\nObjeto de tipo Clientes\n" + ex);
            System.out.println(ex.getMessage());
            return false;
        }

    }

    public boolean updateRow(String idClientes, String idUsuariosClientes, String nombreClientes, String telefonoClientes, String puntosClientes) {
        String query = "UPDATE clientes SET idUsuariosClientes= ?,nombreClientes= ?,telefonoClientes= ?,puntosClientes= ? WHERE idClientes = ?;";
        try {
            this.createPreparedStatement(query);
            this.pstm.setString(1, idUsuariosClientes);
            this.pstm.setString(2, nombreClientes);
            this.pstm.setString(3, telefonoClientes);
            this.pstm.setString(4, puntosClientes);
            try {
                this.pstm.setInt(5, Integer.parseInt(idClientes));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Error al actualizar un registro\nEl número de id no es un número'\nClientes->UpdateRow()\n" + ex);
                return false;
            }
            this.pstm.executeUpdate();
            this.closePreparedStatement();
            return true;
        } catch (HeadlessException | SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al actualizar un registro\nObjeto de tipo Clientes\n" + ex);
            return false;
        }

    }
    
    public boolean updatePointsByID(String clientID, String points){
        String query = "UPDATE clientes SET puntosClientes = ? WHERE idClientes = ?;";
        try{
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(points));
            this.pstm.setInt(2, Integer.parseInt(clientID));
            this.pstm.executeUpdate();
            this.closePreparedStatement();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Hubo un error al actualizar los puntos.\nClientesT()->updatePointsByID()\n"+ex.getMessage());
            return false;
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, "Hubo un error al formatear un dato\nClientesT()->updatePointsByID()\n"+ex.getMessage());
        }
        return true;
    }
}
