/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBPackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author under
 */
public class CarritoT {

    ConnectionDB cnxHandler;
    Connection cnx;
    Statement stm;
    ResultSet rs;
    PreparedStatement pstm;

    public CarritoT() {
        this.cnxHandler = new ConnectionDB();
        if (cnxHandler.establishConnection()) {
            this.cnx = cnxHandler.getCnx();
            //System.out.println("Conexión establecida\nObjeto de tipo Almacen");
        } else {
            JOptionPane.showMessageDialog(null, "Error al establecer conexión\nObjeto de tipo Compra");
        }
    }

    public void createStatement() {

        try {
            this.stm = this.cnx.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear Statement\nObjeto de tipo almacen\n" + ex);
        }

    }

    public void closeStatement() {
        try {
            this.stm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar Statement\nObjeto de tipo almacen\n" + ex);
        }
    }

    public void closeRS() {
        try {
            this.rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar el resultSet\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public void createPreparedStatement(String query) {
        try {
            this.pstm = this.cnx.prepareStatement(query);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public void closePreparedStatement() {
        try {
            this.pstm.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear preparedStatement\nObjeto de tipo almacen\n" + ex.getMessage());
        }
    }

    public String getLastID() {
        String query = "SELECT MAX(idCarrito) FROM carrito;";
        String result = "";
        try {
            this.createPreparedStatement(query);
            this.rs = this.pstm.executeQuery();
            if (this.rs.next()) {
                result = this.rs.getString("MAX(idCarrito)");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el último ID\nCarritoT()->getLastID()");
            return null;
        }
        this.closePreparedStatement();
        this.closeRS();
        return result;
    }

    public ArrayList<String[]> getRowsBySaleID (String ID){
        String query = "SELECT * FROM carrito WHERE idVentaCarrito = ?;";
        ArrayList<String[]> results = new ArrayList<>();
        try{
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(ID));
            this.rs = this.pstm.executeQuery();
            while(this.rs.next()){
                String [] row = new String[6];
                row[0] = this.rs.getString("idCarrito");
                row[1] = this.rs.getString("idClienteCarrito");
                row[2] = this.rs.getString("idVentaCarrito");
                row[3] = this.rs.getString("idProductoCarrito");
                row[4] = this.rs.getString("cantidadProductoCarrito");
                row[5] = this.rs.getString("precioProductoCarrito");
                results.add(row);
            }
            this.closePreparedStatement();
            this.closeRS();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Hubo un error al consultar\nCarritoT()->getRowsBySaleID()\n"+ex.getMessage());
            return null;
        }catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, "Hubo un error al formatear alguno de los datos\nCarritoT()->getRowsByID()\n"+ex.getMessage());
        }
        
        return results;
    }
    
    public boolean insertRow(String idCarrito, String idClienteCarrito, String idVentaCarrito, String idProductoCarrito, String cantidadProductoCarrito, String precioProductoCarrito) {

        String query = "INSERT INTO carrito(idClienteCarrito,idVentaCarrito,idProductoCarrito,cantidadProductoCarrito,precioProductoCarrito) VALUES(?,?,?,?,?);";
        try {
            this.createPreparedStatement(query);
            //this.pstm.setInt(1, Integer.parseInt(idCarrito));
            this.pstm.setInt(1, Integer.parseInt(idClienteCarrito));
            this.pstm.setInt(2, Integer.parseInt(idVentaCarrito));
            this.pstm.setInt(3, Integer.parseInt(idProductoCarrito));
            this.pstm.setInt(4, Integer.parseInt(cantidadProductoCarrito));
            this.pstm.setFloat(5, Float.parseFloat(precioProductoCarrito));
            this.pstm.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al insertar el registro\nCarritoT()->insertRow()\n" + ex.getMessage());
            return false;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Hubo un error al formatear un número\n CarritoT()->insertRow()\n" + ex.getMessage());
            return false;
        }
        
        return true;
    }
    
    public boolean updateStockBySaleIDNProdID(String ID,String ProdID, String stock){
        String query = "UPDATE carrito SET cantidadProductoCarrito = ? WHERE idVentaCarrito = ? AND idProductoCarrito = ?;";
        try{
            this.createPreparedStatement(query);
            this.pstm.setInt(1, Integer.parseInt(stock));
            this.pstm.setInt(2, Integer.parseInt(ID));
            this.pstm.setInt(3, Integer.parseInt(ProdID));
            this.pstm.executeUpdate();
            this.closePreparedStatement();
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "No se pudo actualizar el stock del producto\n"+ex);
            return false;
        }
        return true;
    }
    
}
